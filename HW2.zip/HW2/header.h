#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <vector>
#include <iomanip>

using std::cout;
using std::endl;
using std::setw;
using std::setfill;
using std::internal;
using std::vector;